function my_function()
{
    //document.getElementById("demo").innerHTML="pampashyamal";
    //location.replace('http://127.0.0.1:8000/question_page/')
    location.replace("https://quiz1995.herokuapp.com/question_page/")
}